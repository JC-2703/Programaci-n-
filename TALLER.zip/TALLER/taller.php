<?php


require "config/conex.php";

$cantidad= $_post("cant");
$valor=$_post("val");
$total=$valor*$valor;

if  ($cantidad<=0){

echo="POR FAVOR DIGITA UNA CANTIDAD VALIDA"
}else{
echo="VENTA EXITOSA"

$SQL=" INSERT INTO taller3(cantidad, valor, total) VALUES ($cantidad, $valor, $total)";
 if ($valor<=0)

echo="POR FAVOR DIGITA UN VALOR VALIDO"
else 
echo="VENTA EXITOSA"
}



?>