<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_apellidos'] ?? '';
    $doc = $_POST['documento_tipo'] . " - " . ($_POST['documento_numero'] ?? '');
    $dias = max(1, $_POST['dias_estancia'] ?? 0);
    $habitacion = $_POST['tipo_habitacion'] ?? 'general';
    $acompanantes = $_POST['num_acompanantes'] ?? 0;

    $precio = 100000 * $dias * ($habitacion == "suite" ? 1.1 : 1) + (30000 * $acompanantes * $dias);

    echo "<h2>Reserva</h2><p><strong>Nombre:</strong> $nombre</p><p><strong>Documento:</strong> $doc</p>
          <p><strong>Días:</strong> $dias</p><p><strong>Habitación:</strong> " . ucfirst($habitacion) . "</p>
          <p><strong>Acompañantes:</strong> $acompanantes</p><h3>Total: $" . number_format($precio, 0, ',', '.') . " COP</h3>";
}
?>
