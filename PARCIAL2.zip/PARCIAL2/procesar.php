<?php

require "config/conex.php";

$numero=$_POST["NUMBER"];
$gaseosa=6000;
$aguardiente=10000;
$cerveza=8000;
$value=$gaseosa;
$value=$aguardiente;
$value=$cerveza;
$madre=$_POST["MADRE"];

$total=$value*$numero;

if ($numero<=0){

PRINT("por favor digita una cantidad valida");
}

else{
$sql="INSERT INTO nn( can,Valor) VALUES ($numero,$value)";
PRINT("venta exitosa");
}


?>