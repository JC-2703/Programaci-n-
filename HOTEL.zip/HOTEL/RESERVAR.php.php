<?php

require "config/conex.php";

$habitacion=$_POST("habitacion")



?>