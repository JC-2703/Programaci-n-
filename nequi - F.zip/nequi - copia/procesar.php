<?php

    $saldo = 359000;
    $valor = ($_POST["valor_enviar"]);
    $comision = $valor * 0.004;
    $total = $valor - $comision;

    if ($total > $saldo) {
        echo "<h2>Error: Saldo insuficiente</h2>";
    } else {
        $saldo = $total;

    echo 'transaccion realizada';
    echo 'numero enviado' . $_POST["numero_de_destino"];
    echo 'valor enviado'. $valor;
    echo 'comentario envio' . $_POST["comentario_envio"];
    echo 'saldo' .$total;

    }

?>