<?php

$NUMERO1=$_POST["NUMERO1"];
 $NUMERO2=$_POST["NUMERO2"];
 $TEXT=$_POST["ENVIAR"];
 $IVA=0;
print "Se digito el numero del destino". $NUMERO1;
<if> ($NUMERO2<359.000){"SALDO INSUFICIENTE" . $NUMERO2;
}
<if> ($NUMERO2>359.000);{
$IVA=$NUMERO2*0.004;
$IVA=$NUMERO2+$IVA
print"Se han enviado". $IVA, "pesos a" $NUMERO1;
}

print="$text". "su valor tranferido es", $IVA , "a el numero", "$NUMERO1".;


?>
